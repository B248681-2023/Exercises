#This is my cool script. 
#Also I am worried that my keyboard is slightly broken from where I dropped my laptop earlier. 
# Alas, what is a man to do.
